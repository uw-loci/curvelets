x = load('rawmap.mat');
rawmap = x.rawmap;
img=ones(600,600);

fSize = 64;
fSize2 = ceil(fSize/2);
map2 = nan(size(img));
submap = ones(fSize2*2+1,fSize2*2+1);

% for i = fSize2+1:size(img,1)-(fSize2+1)
%     for j = fSize2+1:size(img,2)-(fSize2+1)
%         tic
%         submap = rawmap(i-fSize2:i+fSize2,j-fSize2:j+fSize2);
%         toc
%         tic
%         ind = find(~isnan(submap)); %in the sub image, find where the map is not nan
%         toc
%         lind = length(ind);
%         if (lind>2)
%             %there must be at least 3 curvelets in region to make std
%             %estimate
%             tic
%             vals = submap(ind);
%             toc
%             tic
%             map2(i,j) = std(vals); %take the standard deviation of the resulting values
%             toc
%             %map2(i,j) = mean(sqrt((mean(vals)-vals).^2));
%             %map2(i,j) = entropy(vals);
%             test1 = 0;
%         end
%     end
% end
tic
[J I] = size(img);
ind = find(~isnan(rawmap));
[y x] = ind2sub([J I],ind);
for i = 1:length(ind)
    ind2 = find(x > x(i)-fSize2 & x < x(i)+fSize2 & y > y(i)-fSize2 & y < y(i)+fSize2);
    xs = x(ind2);
    ys = y(ind2);
    ind3 = sub2ind([J I],y(ind2),x(ind2));
    vals = rawmap(ind3);
    if length(vals) > 2
        map2(y(i),x(i)) = std(vals);
    end
end

figure(600); imagesc(map2); colorbar;

map3 = 127.5 - map2;
figure(650); imagesc(map3); colorbar;
toc
%max filter the map
fSize = 12;
fSize2 = ceil(fSize/2);
map4 = nan(size(img));
tic
% for i = fSize2+1:size(img,1)-(fSize2+1)
%     for j = fSize2+1:size(img,2)-(fSize2+1)
%         map4(i,j) = nanmax(nanmax(map3(i-fSize2:i+fSize2,j-fSize2:j+fSize2)));
%     end
% end 
for i = 1:length(ind)
    val = map3(y(i),x(i));
    rows = y(i)-fSize2:y(i)+fSize2;
    cols = x(i)-fSize2:x(i)+fSize2;
    %get rid of out of bounds coordinates
    ind4 = find(rows > 0 & rows < J & cols > 0 & cols < I);
    rows = rows(ind4);
    cols = cols(ind4);
    %now make a square collection of indices
    lenInd = length(ind4);
    lenInd2 = lenInd*lenInd;
    rows = repmat(rows,1,lenInd);
    cols = reshape(repmat(cols,lenInd,1),1,lenInd2);
    %get the linear indices in the original map
    ind5 = sub2ind([J I],rows,cols);
    %set the value to the max of the current or what was there
    map4(ind5) = max(map4(ind5),val);
end
toc

figure(675); imagesc(map4); colorbar;
%Gaussian blur the map
sig = 4; %in pixels
h = fspecial('gaussian', [10*sig 10*sig], sig);
%uint 8 converts nans to zeros
procmap = imfilter(uint8(map4),h,'replicate');
%map3e = imfilter(map2e,h,'replicate');
figure(700); imagesc(procmap); colorbar;

%try a different method


% for i = -fSize:fSize
%     for j = -fSize:fSize
%         offset = i*J + j;
%         if ~(i==0 && j == 0)
%             icheck = find( x+i>=1 & x+i<=I & y+j>=1 & y+j<=J );
%             
%         end
%     end
% end
