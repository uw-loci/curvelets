clear all;
close all;

t =linspace(0,4*pi,1024);
dt = 4*pi/1024;

v = sin(t);

figure(1); plot(t,v);

for i = 1:length(t)-1
    a(i) = v(i+1) - v(i);
end

figure(2); plot(t(1:length(t)-1),a);

for i = 1:length(t)
    p(i) = sum(v(1:i))*dt;
end

figure(3); plot(t,p);